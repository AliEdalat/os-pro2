#include "worker.h"
#include <sstream>
#include <iostream>
#include <unistd.h>
#include <fcntl.h>


Worker::Worker(std::string input)
{
	file = input;
}

void Worker::set_input(std::string input, std::string fifo)
{
	file = input;
	fifo_name = fifo;
	fd = fopen(fifo_name.c_str(), "w"); 
}

void Worker::extract_header(std::string str)
{
	std::string temp;
	for (int i = 0; i < 26; ++i)
	{
		if (str[i] == ' ' || str[i] == '\n')
		{
			items.push_back(std::string(temp));
			if (str[i] == '\n')
				break;
			temp = "";
			continue;
		}
		temp.push_back(str[i]);
	}
	for (int i = 0; i < items.size(); ++i)
	{
		//std::cout << items[i] << std::endl;
	}
}

void Worker::exec(SearchModel& search_model)
{
	extract_header(file);
	std::istringstream f (&file[26]);
    std::string line;    
    while (std::getline(f, line)) {
        // std::cout << line << std::endl;
        if (line != "\n")
        	extract_items(line);
    }

    std::map<std::string, std::string> map = search_model.get();
    std::map<std::string, std::string>::iterator it = map.begin();
    
    try{ 	
    	for (int i = 0; i < laptops.size(); ++i){
	    	bool selecte = true;
	    	for (std::map<std::string, std::string>::iterator it = map.begin(); it != map.end(); ++it)
	    	{
	    		if(laptops[i].map[it->first] == it->second && selecte){
    				// std::cout << "match" << std::endl;
    				selecte = true;
    			}else{
    				// std::cout << "not match" << std::endl;
    				selecte = false;
    				break;
    			}
	    	}
	    	if (selecte == false){
	    		// std::cout << "continue" << std::endl;
	    		continue;
	    	}
	    	// std::cout << "selecte" << std::endl;
	    	selected_laptops.push_back(i);
	    }
	    for (int i = 0; i < items.size(); ++i)
	    {
	    	if (i == items.size()-1)
    		{
    			fprintf(fd, "%s", items[i].c_str());
    			// std::cout << items[i];
    			continue;
    		}
    		fprintf(fd, "%s ", items[i].c_str());
    		// std::cout << items[i] << " ";
	    }
	    fprintf(fd, "\n");
	    // std::cout << std::endl;
	    for (int i = 0; i < selected_laptops.size(); ++i)
	    {
	    	for (int j = 0; j < items.size(); ++j)
	    	{
	    		if (j == items.size()-1)
	    		{
	    			fprintf(fd, "%s", laptops[selected_laptops[i]].map[items[j]].c_str());
	    			//std::cout << laptops[selected_laptops[i]].map[items[j]];
	    			continue;
	    		}
	    		fprintf(fd, "%s ", laptops[selected_laptops[i]].map[items[j]].c_str());
	    		//std::cout << laptops[selected_laptops[i]].map[items[j]] << " ";
	    	}
	    	fprintf(fd, "\n");
	    	//std::cout << std::endl;
	    }
        fclose(fd); 
	}
	catch(...){
		std::cout << "search ???" << std::endl;
	}
	// std::cout << "find : " << selected_laptops.size() << std::endl;

}

void Worker::extract_items(std::string line)
{
	line += " ";
	laptops.push_back(laptop());
	int state = 0;
	std::string temp;
	for (int i = 0; i < line.length(); ++i)
	{
		if (line[i] == ' ')
		{
			laptops[laptops.size()-1].map[items[state]] = temp;
			state++;
			temp = std::string();
			continue;
		}
		temp.push_back(line[i]);
	}
	for (int i = 0; i < items.size(); ++i)
	{
		if (laptops[laptops.size()-1].map[items[i]] == "")
		{
		 	laptops.pop_back();
		}
		// std::cout << items[i] << " , " << laptops[laptops.size()-1].map[items[i]] << std::endl;	
	}
}