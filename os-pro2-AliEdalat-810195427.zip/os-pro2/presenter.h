#ifndef PERESENTER
#define PERESENTER

#include <string>
#include <vector>
#include "sort_model.h"
#include "laptop.h"
// struct presenter_laptop
// {
// 	std::string brand;
// 	std::string model;
// 	int ram;
// 	int hdd;
// 	int price;
// 	bool header;
// };

class Presenter
{
public:
	Presenter():header(true){}
	void set_input(std::string input);
	void present(SortModel sort_model);

private:
	std::vector<laptop> laptops;
	std::vector<std::string> items;
	std::string file;
	bool header;

	void extract_items(std::string line);
	void extract_header(std::string str);
	
};
#endif