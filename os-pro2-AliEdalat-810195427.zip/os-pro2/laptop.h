#ifndef LAPTOP
#define LAPTOP

struct laptop
{
	// std::string brand;
	// std::string model;
	// int ram;
	// int hdd;
	// int price;
	std::map<std::string, std::string> map;
};

#endif