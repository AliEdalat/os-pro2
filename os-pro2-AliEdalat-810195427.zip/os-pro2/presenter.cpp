#include "presenter.h"
#include <algorithm>
#include <iostream>
#include <sstream>

struct SortStruct
{
	std::string key;
	int model;
	SortStruct(std::string in, int mod):key(in), model(mod){}
	bool operator() (laptop a, laptop b){
		return (model == 1) ? (atoi(a.map[key].c_str()) < atoi(b.map[key].c_str())) : (atoi(a.map[key].c_str()) > atoi(b.map[key].c_str()));
	}
	
};

void Presenter::extract_header(std::string str)
{
	// std::cout << str << std::endl;
	std::string temp;
	for (int i = 0; i < 26; ++i)
	{
		if (str[i] == ' ' || str[i] == '\n')
		{
			items.push_back(std::string(temp));
			if (str[i] == '\n')
				break;
			temp = "";
			continue;
		}
		temp.push_back(str[i]);
	}
	for (int i = 0; i < items.size(); ++i)
	{
		// std::cout << items[i] << std::endl;
	}
}

void Presenter::set_input(std::string input)
{
	file = input;
	if (header == true)
	{
		extract_header(input);
		header = false;
	}
	std::istringstream f (&file[26]);
    std::string line;    
    while (std::getline(f, line)) {
        //std::cout << line << std::endl;
        if (line != "\n")
        	extract_items(line);
    }
}

void Presenter::present(SortModel sort_model)
{
	std::map<std::string, std::string> map = sort_model.get();
	for (std::map<std::string, std::string>::iterator it = map.begin(); it != map.end(); ++it)
	{
		SortStruct sort_struct(it->first, ((it->second == "descend") ? 0 : 1));
		std::sort(laptops.begin(), laptops.end(), sort_struct);
	}

	for (int i = 0; i < laptops.size(); ++i)
	{
		for (int j = 0; j < items.size() ; ++j)
		{
			std::cout << laptops[i].map[items[j]] << " ";
		}
		std::cout<< std::endl;
	}

}

void Presenter::extract_items(std::string line)
{
	line += " ";
	laptops.push_back(laptop());
	int state = 0;
	std::string temp;
	for (int i = 0; i < line.length(); ++i)
	{
		if (line[i] == ' ')
		{
			laptops[laptops.size()-1].map[items[state]] = temp;
			state++;
			temp = std::string();
			continue;
		}

		temp.push_back(line[i]);
	}
	for (int i = 0; i < items.size(); ++i)
	{
		if (laptops[laptops.size()-1].map[items[i]] == "")
		{
		 	laptops.pop_back();
		}
		// std::cout << items[i] << " , " << laptops[laptops.size()-1].map[items[i]] << std::endl;	
	}
}