#ifndef WORKER
#define WORKER

#include <string>
#include <vector>
#include <stdio.h>

#include "search_model.h"
#include "laptop.h"

class Worker
{
public:
	Worker(){}
	Worker(std::string input);
	void exec(SearchModel& search_model);
	void set_input(std::string input, std::string fifo);
	
private:
	std::string file;
	std::string fifo_name;
	std::vector<laptop> laptops;
	std::vector<int> selected_laptops;
	std::vector<std::string> items;
	FILE * fd;

	void extract_items(std::string line);
	void extract_header(std::string str);
};
#endif